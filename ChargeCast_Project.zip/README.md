
# ChargeCast - EV Charging Demand Forecasting

## Overview
ChargeCast forecasts hourly EV charging demand using
historical real-world electric vehicle charging sessions.

## Dataset
A dataset for multi-faceted analysis of electric vehicle
charging transactions.

Source: https://doi.org/10.6084/m9.figshare.22495141.v1

The source dataset contains 72,856 charging sessions
collected between September 2021 and September 2022.

## Problem
Charging operators need to anticipate demand to plan
charger capacity and electricity requirements.

## Technologies
Python, Pandas, NumPy, Matplotlib, Seaborn,
Scikit-learn and Joblib.

## Workflow
1. Data acquisition
2. Data cleaning
3. Hourly demand aggregation
4. Exploratory data analysis
5. Time-based feature engineering
6. Chronological train-test split
7. Forecasting model training
8. Model comparison
9. Error analysis
10. 24-hour recursive forecasting

## Models
- Seasonal Naive baseline
- Random Forest Regressor
- Histogram Gradient Boosting Regressor

## Best Model
Random Forest

## Evaluation
MAE: 57.2588 kWh
RMSE: 78.0563 kWh
R2: 0.6806

## Important Methodology Note
Session energy is assigned to the hour in which the
charging session begins. This is a session-start demand
proxy, not metered electricity consumption in each hour.

The 24-hour forecast is recursive. Test-set metrics use
observed historical lag values for one-step-ahead evaluation.

## Limitations
- The dataset covers one commercial operator in South Korea.
- The observations cover one year only.
- The demand proxy does not distribute energy across
  the complete charging duration.
- Results should not be interpreted as a live grid forecast.

## Author
Aditya Dhage

Data Science | Machine Learning | EV Analytics
